global = 10

print("Hi")

wstr = L"Wide character string"
print(wstr)