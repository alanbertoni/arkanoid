global = 10

print("Hi")